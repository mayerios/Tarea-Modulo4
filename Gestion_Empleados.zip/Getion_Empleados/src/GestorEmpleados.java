import java.util.ArrayList;
import java.util.List;

public class GestorEmpleados {
     private List<Empleado> listaEmpleados;

    public GestorEmpleados() {
        this.listaEmpleados = new ArrayList<>();
    }

    public void agregarEmpleado(Empleado empleado) {
        listaEmpleados.add(empleado);
        System.out.println("Empleado agregado exitosamente.");
    }

    public void mostrarEmpleados() {
        if (listaEmpleados.isEmpty()) {
            System.out.println("No hay empleados para mostrar.");
        } else {
            System.out.println("Lista de empleados:");
            for (Empleado empleado : listaEmpleados) {
                empleado.mostrarInformacion();
                System.out.println("-----------------------");
            }
        }
    }
}
